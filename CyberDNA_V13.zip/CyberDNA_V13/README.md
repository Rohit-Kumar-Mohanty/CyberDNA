# CyberDNA V12
## Live Iris + Blink Liveness + AI/ML Security Intelligence

V10.1 fixes the main V9 liveness weakness: ordinary webcam eye detectors can
temporarily lose the eye when the eyelids close. V9 discarded those frames,
which made an intentional blink appear as `0 detected`.

### V10 changes

- Tolerant blink state machine.
- Open → closed → open temporal sequence.
- Short frame history is preserved during temporary eye-detector loss.
- Face-relative eye crop fallback during a likely blink.
- Smoothed eye-openness signal.
- Natural movement remains a supporting liveness signal.
- AI/ML security risk engine remains integrated and now updates continuously during live capture.
- Explainable findings remain integrated.
- Local audit log remains integrated.
- Rohit Kumar Mohanty branding and live clock retained.

### Test

```powershell
Ctrl+C
python -m pip install -r requirements.txt
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

Then:

1. Start Camera.
2. Look directly at the camera with one eye visible.
3. Wait a few seconds for calibration.
4. Blink once deliberately: **open → close → open**.
5. Keep the eye open for another 2–3 seconds.
6. Confirm **BLINKS: 1 detected**.

### Important limitation

This is a research/portfolio liveness heuristic. It is not a certified
presentation-attack detector and should not be represented as production-grade
biometric authentication.

The ML risk model uses synthetic training examples. Production deployment
would require real validation data, calibrated thresholds, stronger liveness
methods, secure biometric template protection, consent controls, and a full
privacy/security review.

### V10.1 fix
The Intelligence Engine no longer waits for `CAPTURE READY` before displaying an ML assessment. It continuously evaluates the current capture. Template similarity remains provisional until enrollment/verification is performed.

### V10.2 fixes
- Prevents stale asynchronous liveness responses from overwriting a newer liveness state.
- Prevents stale ML responses from overwriting newer risk results.
- Removes the artificial `0.45` similarity value from the live UI.
- Similarity remains `--` until an iris template is actually enrolled.
- ML risk uses a neutral internal feature only for the model vector when no template exists.
- Explainable findings now distinguish missing enrollment from an actual low-similarity identity result.


### V11 enrollment and verification
V11 adds explicit local identity-template status, multi-frame enrollment metadata, and a fresh multi-frame verification gate. Verification requires an enrolled template, sufficient capture quality, and liveness before a match can be marked verified. This remains a research/portfolio prototype, not production biometric authentication.


### V12 capture policy
Enrollment uses an adaptive webcam-quality gate so glasses, camera distance and short capture sessions do not make the prototype unnecessarily difficult. Verification remains stricter and still requires similarity, liveness and quality gates.


### V13 liveness refinement

The liveness window now samples more frequently and uses a temporal valley
heuristic plus eyelid/iris signals, making natural blinks easier to detect on
ordinary webcams. This remains a research/portfolio heuristic and is not a
certified presentation-attack detector.
