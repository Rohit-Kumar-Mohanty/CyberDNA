const video=document.getElementById("video");
const canvas=document.createElement("canvas");
const overlay=document.getElementById("overlay");
const startBtn=document.getElementById("startBtn");
const enrollBtn=document.getElementById("enrollBtn");
const scanBtn=document.getElementById("scanBtn");
const statusEl=document.getElementById("status");
const dot=document.getElementById("dot");
const message=document.getElementById("message");
const readyBadge=document.getElementById("readyBadge");
let stream=null, monitorTimer=null, livenessTimer=null, samples=[], frameBuffer=[], lastResult=null, busy=false, liveScore=50, blinkEvents=0, liveMovement=0, livenessRequestId=0, intelligenceRequestId=0, enrolled=false;

function updateClock(){
  document.getElementById("clock").textContent=new Date().toLocaleTimeString([],{
    hour:"2-digit",minute:"2-digit",second:"2-digit"
  });
}
setInterval(updateClock,1000);updateClock();

function setStatus(text,online=false){statusEl.textContent=text;dot.style.background=online?"var(--accent)":"#687984"}

async function loadProfileStatus(){try{const r=await fetch("/api/profile");const d=await r.json();enrolled=!!d.enrolled;const e=document.getElementById("enrollStatus");if(e)e.textContent=enrolled?"ENROLLED":"NOT ENROLLED";const b=document.getElementById("identityBadge");if(b)b.textContent=enrolled?"IDENTITY TEMPLATE ACTIVE":"NO TEMPLATE";if(enrolled){const q=document.getElementById("scanBtn");if(q)q.textContent="Verify Live";const ps=document.getElementById("profileStatus");if(ps)ps.textContent=`Local template enrolled • ${d.profile?.frames_used||"--"} frames`;}}catch(e){}}
loadProfileStatus();

async function startCamera(){
  try{
    stream=await navigator.mediaDevices.getUserMedia({
      video:{facingMode:"user",width:{ideal:1920},height:{ideal:1080}},audio:false
    });
    video.srcObject=stream;await video.play();
    setStatus("Camera live",true);
    startBtn.textContent="Camera Running";startBtn.disabled=true;
    enrollBtn.disabled=true;scanBtn.disabled=true;
    readyBadge.textContent="SEARCHING";samples=[];frameBuffer=[];
    message.textContent="CyberDNA is calibrating the live iris capture...";
    monitorTimer=setInterval(sampleFrame,500); livenessTimer=setInterval(checkLiveness,900);
  }catch(e){setStatus("Camera blocked");message.textContent="Camera access was not granted. Check browser permissions."}
}

function captureFrame(){
  if(!video.videoWidth)return null;
  canvas.width=video.videoWidth;canvas.height=video.videoHeight;
  canvas.getContext("2d").drawImage(video,0,0,canvas.width,canvas.height);
  return canvas.toDataURL("image/jpeg",0.88);
}

function drawOverlay(data){
  const ctx=overlay.getContext("2d");
  overlay.width=video.videoWidth||640;overlay.height=video.videoHeight||400;
  ctx.clearRect(0,0,overlay.width,overlay.height);
  if(data.face_box){const[x,y,w,h]=data.face_box;ctx.strokeStyle="rgba(77,214,167,.28)";ctx.lineWidth=2;ctx.strokeRect(x,y,w,h)}
  if(data.eye_box){const[x,y,w,h]=data.eye_box;ctx.strokeStyle="#4dd6a7";ctx.lineWidth=3;ctx.strokeRect(x,y,w,h)}
  if(data.iris){const[cx,cy,r]=data.iris;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke()}
}

function setBar(id,value){
  const v=Math.max(0,Math.min(100,Number(value)||0));
  document.getElementById(id+"Bar").style.width=v+"%";
  document.getElementById(id+"Val").textContent=v+"%";
}
function showComponents(c){
  if(!c)return;
  setBar("focus",c.focus);setBar("light",c.illumination);setBar("contrast",c.contrast);
  setBar("visibility",c.visibility);setBar("resolution",c.resolution);
}
function avg(a){return a.reduce((x,y)=>x+y,0)/Math.max(1,a.length)}
function std(a){if(a.length<2)return 0;const m=avg(a);return Math.sqrt(avg(a.map(x=>(x-m)**2)))}


async function checkLiveness(){
  if(frameBuffer.length<3)return;
  const requestId=++livenessRequestId;
  const frames=frameBuffer.slice(-10);
  try{
    const res=await fetch("/api/liveness",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({frames:frameBuffer.slice(-10)})
    });
    const data=await res.json();
    if(!data.ok || requestId!==livenessRequestId)return;
    liveScore=data.score;
    blinkEvents=data.blink_events||0;
    liveMovement=data.movement||0;
    document.getElementById("liveScore").textContent=data.score;
    const blinkEl=document.getElementById("blinkCount"); if(blinkEl)blinkEl.textContent=blinkEvents+" detected";
    const moveEl=document.getElementById("movementScore"); if(moveEl)moveEl.textContent=liveMovement+"%";
    document.getElementById("liveState").textContent=data.state;
    document.getElementById("liveMessage").textContent=data.message;

    if(data.state==="LIVE"){
      document.getElementById("liveState").style.color="var(--accent)";
      document.getElementById("guidanceText").textContent="Liveness challenge passed. Keep the eye centered while capture quality stabilizes.";
    }else{
      document.getElementById("liveState").style.color="var(--warn)";
    }
  }catch(e){}
}

async function sampleFrame(){
  if(busy)return;
  const frame=captureFrame();if(!frame)return;
  busy=true;
  try{
    const res=await fetch("/api/quality",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({frame})});
    const data=await res.json();
    if(!data.ok)throw new Error(data.error||"Quality check failed.");

    if(!data.detected){
      samples=[]; readyBadge.textContent="SEARCHING";
      enrollBtn.disabled=true;scanBtn.disabled=true;
      message.textContent=data.message || "Keep your eye visible."; busy=false;return;
    }

    drawOverlay(data);
    lastResult={...data,frame};
    samples.push(data);
    frameBuffer.push(frame);
    if(samples.length>10)samples.shift();
    if(frameBuffer.length>10)frameBuffer.shift();

    const qs=samples.map(x=>x.quality), avgQ=avg(qs), stability=Math.max(0,100-std(qs)*7);
    document.getElementById("quality").textContent=Math.round(avgQ)+"%";
    document.getElementById("qualityState").textContent=(samples.length>=6&&avgQ>=62&&stability>=82)?"READY":"SCANNING";
    showComponents(data.components);

    // V10.1: continuously score the current capture. The ML dashboard should
    // not remain blank while the quality gate is waiting for better frames.
    // Similarity stays unknown until an enrolled template exists.
    runIntelligence({
      quality:avgQ,
      focus:data.components.focus,
      illumination:data.components.illumination,
      contrast:data.components.contrast,
      visibility:data.components.visibility,
      resolution:data.components.resolution,
      liveness:liveScore,
      stability:stability,
      similarity:null
    });

    if(data.eye_preview){
      const img=document.getElementById("eyePreview");
      if(img){img.src="data:image/jpeg;base64,"+data.eye_preview;img.classList.add("visible")}
    }

    const enrollmentReady=samples.length>=6&&avgQ>=48&&stability>=65&&data.quality>=45&&liveScore>=60&&blinkEvents>=1;
    if(enrollmentReady){
      readyBadge.textContent=enrolled?"VERIFY READY":"ENROLL READY";
      enrollBtn.disabled=enrolled;
      scanBtn.disabled=!enrolled;
      document.getElementById("qualityState").textContent="READY";
      message.textContent=enrolled?`Fresh capture ready • quality ${Math.round(avgQ)}% • liveness ${liveScore}%`:`Enrollment-ready capture • quality ${Math.round(avgQ)}% • liveness ${liveScore}%`;
      document.getElementById('guidanceText').textContent=enrolled?'Fresh capture is ready. Click Verify Live.':'Good enough for local enrollment. Click Enroll Iris.';
    }else{
      readyBadge.textContent="SCANNING";enrollBtn.disabled=true;scanBtn.disabled=true;
      if(blinkEvents<1){message.textContent="Liveness challenge: blink once, then keep your eye open.";document.getElementById("guidanceText").textContent="Blink once naturally. A single natural blink is enough.";}
      else if(data.components.focus<35){message.textContent="Focus is low: move slightly closer and keep your eye steady.";document.getElementById("guidanceText").textContent="Move slightly closer for a moment, then relax.";}
      else if(data.components.illumination<45){message.textContent="Lighting is low: face a soft light source and avoid glare.";document.getElementById("guidanceText").textContent="Face a soft light source. Avoid direct glare on the eye.";}
      else if(data.components.visibility<50){message.textContent="Iris visibility is low: open your eye naturally and face the camera.";document.getElementById("guidanceText").textContent="Open your eye naturally and look directly at the camera.";}
      else if(std(qs)>7){message.textContent="Stabilizing capture: keep your head still...";document.getElementById("guidanceText").textContent="Keep your head steady for a moment.";}
      else message.textContent=`Calibrating capture: ${samples.length}/6`;
    }
  }catch(e){message.textContent=e.message}
  finally{busy=false}
}

async function send(path,frames){
  const res=await fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({frames})});
  return await res.json();
}


function renderIntelligence(info){
  if(!info)return;
  const score=document.getElementById("risk");
  const level=document.getElementById("riskLevel");
  const verdict=document.getElementById("mlVerdict");
  const findings=document.getElementById("mlFindings");
  const model=document.getElementById("mlModel");
  if(score)score.textContent=info.score+"/100";
  const sim=document.getElementById("similarity");
  if(sim && info.template_available===false) sim.textContent="--";
  if(level)level.textContent=info.level;
  if(verdict)verdict.textContent=info.verdict;
  if(model)model.textContent=info.model;
  if(findings){
    findings.innerHTML=(info.findings||[]).map(f =>
      `<div class="finding"><span>${f.signal}</span><strong>${f.severity}</strong><p>${f.explanation}</p></div>`
    ).join("");
  }
  const controlMap=info.controls||{};
  Object.keys(controlMap).forEach(k=>{
    const el=document.getElementById("ctrl-"+k);
    if(el){
      el.textContent=controlMap[k]?"PASS":"CHECK";
      el.className=controlMap[k]?"control-pass":"control-check";
    }
  });
}

async function runIntelligence(features){
  const requestId=++intelligenceRequestId;
  try{
    const res=await fetch("/api/intelligence",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({features})
    });
    const data=await res.json();
    if(data.ok && requestId===intelligenceRequestId)renderIntelligence(data);
  }catch(e){}
}

function showResult(data){
  if(!data.ok){message.textContent=data.error||"Scan failed.";return}
  if(!data.detected){message.textContent=data.message;return}
  drawOverlay(data);
  document.getElementById("quality").textContent=data.quality+"%";
  document.getElementById("confidence").textContent=data.confidence==null?"--":data.confidence+"%";
  document.getElementById("similarity").textContent=data.similarity==null?"--":data.similarity;
  document.getElementById("qualityState").textContent="LOCKED"; document.getElementById("liveScore").textContent=data.stability!=null?Math.max(liveScore,data.stability):liveScore;
  showComponents(data.components); if(data.intelligence){renderIntelligence(data.intelligence);}
  if(data.stability!=null)message.textContent=`Verification capture locked • quality ${data.quality}% • stability ${data.stability}%`;

  if(data.matched){
    document.getElementById("matchTag").textContent="VERIFIED";document.getElementById("matchTag").className="tag";
    document.getElementById("profileStatus").textContent="Multi-frame local iris template matched";
    document.getElementById("risk").textContent=(data.intelligence?.score ?? data.profile.risk)+"/100"; renderIntelligence(data.intelligence);
    document.getElementById("assessmentText").textContent=`${data.intelligence?.verdict || "Verification complete"}. ${data.intelligence?.findings?.[0]?.explanation || "Security assessment completed."}`;
  }else{
    document.getElementById("matchTag").textContent="NOT VERIFIED";document.getElementById("matchTag").className="tag neutral";
    document.getElementById("profileStatus").textContent=data.similarity==null?"No iris template enrolled":"Iris similarity below prototype threshold";
    document.getElementById("risk").textContent="--";
    document.getElementById("assessmentText").textContent=data.similarity==null?"Enroll a stable multi-frame iris capture first.":"The stable multi-frame iris did not meet the prototype similarity threshold.";
  }
}

startBtn.addEventListener("click",startCamera);

enrollBtn.addEventListener("click",async()=>{
  if(frameBuffer.length<6){message.textContent="Wait for CAPTURE READY first.";return}
  enrollBtn.disabled=true;scanBtn.disabled=true;message.textContent="Building multi-frame iris template locally...";
  try{
    const data=await send("/api/enroll",frameBuffer);
    if(data.ok){enrolled=true;document.getElementById("enrollStatus").textContent="ENROLLED";document.getElementById("identityBadge").textContent="IDENTITY TEMPLATE ACTIVE";document.getElementById("scanBtn").textContent="Verify Live";document.getElementById("profileStatus").textContent=`Local template enrolled • ${data.frames_used} frames`;message.textContent=`Iris identity enrolled from ${data.frames_used} frames at ${data.quality}% average quality.`;}else message.textContent=data.error;
  }catch(e){message.textContent=e.message}
  finally{enrollBtn.disabled=false;scanBtn.disabled=false}
});

scanBtn.addEventListener("click",async()=>{
  if(!enrolled){message.textContent="Enroll an iris template first.";return}
  if(frameBuffer.length<6){message.textContent="Wait for CAPTURE READY first.";return}
  scanBtn.disabled=true;enrollBtn.disabled=true;message.textContent="Locking and verifying multiple iris frames...";
  try{showResult(await send("/api/scan",frameBuffer))}
  catch(e){message.textContent=e.message}
  finally{scanBtn.disabled=false;enrollBtn.disabled=false}
});

window.addEventListener("beforeunload",()=>{
  if(monitorTimer)clearInterval(monitorTimer); if(livenessTimer)clearInterval(livenessTimer);
  if(stream)stream.getTracks().forEach(t=>t.stop());
});
