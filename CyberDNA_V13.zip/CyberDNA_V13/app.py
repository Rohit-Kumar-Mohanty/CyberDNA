from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np
import base64
import json
from pathlib import Path
from datetime import datetime, timezone

app = Flask(__name__)
DATA_DIR = Path("data")
TEMPLATE_FILE = DATA_DIR / "iris_template.npy"
PROFILE_FILE = DATA_DIR / "profile.json"
DATA_DIR.mkdir(exist_ok=True)

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)
eye_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_eye_tree_eyeglasses.xml"
)


# ---------------------------------------------------------------------------
# CyberDNA ML Security Risk Engine
# ---------------------------------------------------------------------------
# A small, dependency-light Gaussian classifier is trained at startup on
# synthetic security-session examples. It predicts whether the current
# biometric session looks normal or suspicious from capture/liveness signals.
# This is a portfolio ML component, not a production fraud detector.

class CyberDNARiskModel:
    FEATURES = [
        "quality", "focus", "illumination", "contrast",
        "visibility", "resolution", "liveness",
        "stability", "similarity"
    ]

    def __init__(self, seed=42):
        rng = np.random.default_rng(seed)

        # Synthetic training distribution. Class 0 = normal, class 1 = risky.
        n = 900
        normal = np.column_stack([
            rng.normal(78, 10, n),
            rng.normal(74, 14, n),
            rng.normal(76, 12, n),
            rng.normal(73, 13, n),
            rng.normal(80, 11, n),
            rng.normal(88, 8, n),
            rng.normal(88, 8, n),
            rng.normal(88, 7, n),
            rng.normal(0.86, 0.055, n),
        ])
        risky = np.column_stack([
            rng.normal(45, 18, n),
            rng.normal(38, 20, n),
            rng.normal(42, 18, n),
            rng.normal(40, 20, n),
            rng.normal(45, 19, n),
            rng.normal(68, 17, n),
            rng.normal(57, 20, n),
            rng.normal(58, 19, n),
            rng.normal(0.56, 0.13, n),
        ])

        X = np.vstack([normal, risky])
        y = np.concatenate([np.zeros(n, dtype=int), np.ones(n, dtype=int)])
        X[:, :-1] = np.clip(X[:, :-1], 0, 100)
        X[:, -1] = np.clip(X[:, -1], 0, 1)

        self.means = np.array([X[y == 0, i].mean() for i in range(X.shape[1])])
        self.stds = np.array([X[y == 0, i].std() + 1e-3 for i in range(X.shape[1])])
        self.risky_means = np.array([X[y == 1, i].mean() for i in range(X.shape[1])])
        self.risky_stds = np.array([X[y == 1, i].std() + 1e-3 for i in range(X.shape[1])])
        self.normal_prior = 0.5
        self.risky_prior = 0.5

    def predict(self, values):
        x = np.array([float(values.get(k, 0)) for k in self.FEATURES], dtype=np.float64)
        # Convert similarity from 0..1 to a 0..100 scale for feature balance.
        x[-1] *= 100.0
        normal_mu = self.means.copy()
        risky_mu = self.risky_means.copy()
        normal_sd = self.stds.copy()
        risky_sd = self.risky_stds.copy()

        def log_gaussian(mu, sd):
            return float(np.sum(
                -0.5 * np.log(2 * np.pi * (sd ** 2))
                - ((x - mu) ** 2) / (2 * (sd ** 2))
            ))

        ln_normal = log_gaussian(normal_mu, normal_sd) + np.log(self.normal_prior)
        ln_risky = log_gaussian(risky_mu, risky_sd) + np.log(self.risky_prior)
        z = max(ln_normal, ln_risky)
        p_risky = float(np.exp(ln_risky - z) / (np.exp(ln_normal - z) + np.exp(ln_risky - z)))

        # Blend probabilistic output with explicit biometric security gates.
        gates = []
        if values.get("liveness", 0) < 60:
            gates.append(18)
        if values.get("quality", 0) < 55:
            gates.append(12)
        if values.get("stability", 0) < 65:
            gates.append(10)
        # Similarity is not a risk signal until a local template exists.
        # A missing template must not be converted into an artificial 0.45
        # similarity and then treated as an identity mismatch.
        similarity = values.get("similarity")
        if similarity is not None and similarity < 0.70:
            gates.append(12)

        score = int(np.clip(p_risky * 100 + sum(gates), 0, 100))
        if score >= 70:
            level = "HIGH"
        elif score >= 40:
            level = "MEDIUM"
        else:
            level = "LOW"

        return score, level, p_risky

    def explain(self, values):
        checks = [
            ("Liveness", float(values.get("liveness", 0)), 70, "Low liveness cue increases presentation-attack concern."),
            ("Capture quality", float(values.get("quality", 0)), 60, "Low image quality makes biometric evidence less trustworthy."),
            ("Stability", float(values.get("stability", 0)), 70, "Unstable frames weaken the reliability of the captured template."),
            ("Focus", float(values.get("focus", 0)), 55, "Poor focus reduces useful iris texture."),
        ]
        findings = []
        for name, value, threshold, text in checks:
            if value < threshold:
                findings.append({
                    "signal": name,
                    "value": round(value),
                    "severity": "HIGH" if value < threshold - 20 else "MEDIUM",
                    "explanation": text
                })

        # Similarity is a verification signal, not a penalty before enrollment.
        if values.get("similarity") is not None:
            sim = float(values["similarity"]) * 100
            if sim < 75:
                findings.append({
                    "signal": "Similarity",
                    "value": round(sim),
                    "severity": "HIGH" if sim < 55 else "MEDIUM",
                    "explanation": "Low template similarity can indicate an unknown or inconsistent identity."
                })
        else:
            findings.append({
                "signal": "Template",
                "value": None,
                "severity": "INFO",
                "explanation": "No enrolled iris template is available, so identity similarity is not scored yet."
            })

        return findings[:5]


risk_model = CyberDNARiskModel()
AUDIT_FILE = DATA_DIR / "security_audit.jsonl"

def write_audit(event, payload):
    DATA_DIR.mkdir(exist_ok=True)
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": event,
        "payload": payload
    }
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, separators=(",", ":")) + "\\n")

def decode_frame(data_url):
    if "," in data_url:
        data_url = data_url.split(",", 1)[1]
    raw = base64.b64decode(data_url)
    arr = np.frombuffer(raw, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)

def normalize_iris(iris_gray, mask, cx, cy, pupil_r, iris_r):
    """Create a scale-normalized polar iris descriptor."""
    if iris_gray.size == 0:
        return None

    # Rubber-sheet style normalization: sample concentric rings from the
    # pupil boundary to the iris boundary. This reduces sensitivity to scale.
    h, w = iris_gray.shape
    angles = np.linspace(0, 2*np.pi, 128, endpoint=False, dtype=np.float32)
    radii = np.linspace(1.12, 0.94, 48, dtype=np.float32)

    rr = np.maximum(pupil_r * radii[:, None], pupil_r + 1.0)
    theta = angles[None, :]
    xs = cx + rr * np.cos(theta)
    ys = cy + rr * np.sin(theta)

    valid_xy = (
        (xs >= 0) & (xs < w) &
        (ys >= 0) & (ys < h)
    )
    map_x = xs.astype(np.float32)
    map_y = ys.astype(np.float32)

    polar = cv2.remap(
        iris_gray.astype(np.uint8), map_x, map_y,
        interpolation=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT_101
    )

    # Normalize each ring to reduce lighting differences.
    polar = polar.astype(np.float32)
    for i in range(polar.shape[0]):
        row = polar[i]
        m = float(row.mean())
        sd = float(row.std()) + 1e-6
        polar[i] = np.clip((row - m) / sd, -3, 3) / 3.0

    # Mask samples outside the eye image.
    polar[~valid_xy] = 0

    # Blur only lightly, then downsample for a stable descriptor.
    polar = cv2.GaussianBlur(polar, (3, 3), 0.5)
    polar = cv2.resize(polar, (96, 36), interpolation=cv2.INTER_AREA)

    return polar.astype(np.float32)



def eye_motion_signature(eye_gray, iris_r=None, eye_h=None, visibility=None):
    """Extract temporal eye signals used by the prototype liveness layer."""
    if eye_gray is None or eye_gray.size == 0:
        return None
    small = cv2.resize(eye_gray, (96, 48), interpolation=cv2.INTER_AREA)
    edges = cv2.Canny(small, 50, 130)
    h, w = small.shape
    roi = small[int(h*0.12):int(h*0.88), int(w*0.08):int(w*0.92)]
    # Relative dark-pixel area provides a rough eye-state signal.
    local_mean=float(roi.mean()) if roi.size else 128.0
    threshold=max(25.0, local_mean-32.0)
    dark_ratio=float((roi < threshold).mean()) if roi.size else 0.0
    iris_ratio=(float(iris_r)/max(1.0,float(eye_h))) if eye_h else 0.0
    return {
        "mean": float(small.mean()),
        "std": float(small.std()),
        "edge_density": float((edges > 0).mean()),
        "dark_ratio": dark_ratio,
        "iris_ratio": iris_ratio,
        "visibility": float(visibility if visibility is not None else 0),
        # Horizontal eyelid-edge strength. During a blink the visible iris
        # often disappears while the upper/lower lid boundary becomes the
        # dominant structure. This is a webcam-friendly heuristic, not a
        # biometric-grade eyelid model.
        "lid_signal": float(np.clip(edges[int(h*0.30):int(h*0.70)].mean() / 255.0, 0, 1))
    }

def liveness_sequence(results):
    """Research/portfolio blink + motion heuristic.

    V10 is intentionally tolerant of the common webcam behavior where the
    eye detector temporarily loses the eye during a blink. It uses temporal
    eye openness plus motion instead of requiring every frame to be detected.
    It is not a certified presentation-attack detector.
    """
    if len(results) < 4:
        return {"score": 50, "state": "CALIBRATING", "blink_events": 0,
                "movement": 0, "eye_state": "UNKNOWN",
                "message": "Collecting more live frames..."}

    stats = [r.get("eye_stats") for r in results if r.get("eye_stats")]
    if len(stats) < 4:
        return {"score": 50, "state": "CALIBRATING", "blink_events": 0,
                "movement": 0, "eye_state": "UNKNOWN",
                "message": "Keep one eye visible while CyberDNA calibrates."}

    # Build a robust openness signal. The normalized iris-to-eye ratio is
    # useful when the iris is visible; dark-ratio is used as a secondary cue.
    openness = []
    for st in stats:
        iris_part = np.clip(st.get("iris_ratio", 0.0) * 3.2, 0, 1)
        visibility_part = np.clip(st.get("visibility", 0.0) / 100.0, 0, 1)
        dark = np.clip(st.get("dark_ratio", 0.0), 0, 1)
        lid = np.clip(st.get("lid_signal", 0.0), 0, 1)
        # Give iris visibility the strongest weight, but retain temporal
        # structure and darkness so a blink can be recognized even when Haar
        # keeps returning an eye box for partially closed eyes.
        value = 0.45 * iris_part + 0.32 * visibility_part + 0.13 * (1.0 - dark) + 0.10 * lid
        openness.append(float(value))

    # Smooth the signal to avoid a single noisy webcam frame creating a blink.
    smoothed = []
    for i in range(len(openness)):
        lo = max(0, i - 1)
        hi = min(len(openness), i + 2)
        smoothed.append(float(np.mean(openness[lo:hi])))

    # Dynamic baseline from the user's currently open-eye frames.
    baseline = float(np.percentile(smoothed, 75))
    close_threshold = max(0.30, baseline * 0.76)
    open_threshold = max(0.42, baseline * 0.88)

    states = ["OPEN" if v >= open_threshold else "CLOSED" if v <= close_threshold else "TRANSITION"
              for v in smoothed]

    # Collapse TRANSITION states so an open -> transition -> closed ->
    # transition -> open sequence can still count.
    simplified = []
    for st in states:
        if st == "TRANSITION" and simplified:
            simplified.append(simplified[-1])
        else:
            simplified.append(st)

    blink_events = 0
    # A blink is an open -> pronounced valley -> open transition. The valley
    # can be only one sampled frame because the browser samples every ~0.5s.
    for i in range(1, len(smoothed)-1):
        left = max(smoothed[:i])
        right = max(smoothed[i+1:]) if i+1 < len(smoothed) else 0
        valley = smoothed[i]
        if left >= open_threshold and right >= open_threshold and valley <= close_threshold:
            blink_events = 1
            break

    # Also recognize a short run of low openness between two open regions.
    if blink_events == 0:
        for i in range(1, len(smoothed)-2):
            if (max(smoothed[:i]) >= open_threshold and
                max(smoothed[i+2:]) >= open_threshold and
                min(smoothed[i:i+2]) <= close_threshold):
                blink_events = 1
                break

    # Motion signal from the eye texture statistics.
    deltas = []
    for x, y in zip(stats, stats[1:]):
        delta = (
            abs(x["mean"] - y["mean"]) * 0.35 +
            abs(x["std"] - y["std"]) * 0.65 +
            abs(x["edge_density"] - y["edge_density"]) * 105 +
            abs(x["dark_ratio"] - y["dark_ratio"]) * 55
        )
        deltas.append(delta)

    movement = float(np.clip(np.mean(deltas) * 15.0, 0, 100)) if deltas else 0.0

    if blink_events >= 1:
        score = int(np.clip(82 + movement * 0.12, 0, 97))
        state = "LIVE"
        message = "Blink transition detected with natural frame movement."
    elif movement >= 20:
        score = int(np.clip(58 + movement * 0.18, 0, 80))
        state = "RECHECK"
        message = "Natural movement detected. Blink once to strengthen liveness confidence."
    else:
        score = int(np.clip(35 + movement * 0.25, 0, 65))
        state = "CAUTION"
        message = "Low natural variation. Blink once and keep your eye visible."

    current = simplified[-1] if simplified else "UNKNOWN"
    return {"score": score, "state": state, "blink_events": blink_events,
            "movement": int(round(movement)), "eye_state": current,
            "message": message}



def crop_preview(frame, box, iris=None):
    """Return a zoomed eye crop for the browser UI."""
    x, y, w, h = box
    pad = int(max(w, h) * 0.55)
    x0, y0 = max(0, x-pad), max(0, y-pad)
    x1, y1 = min(frame.shape[1], x+w+pad), min(frame.shape[0], y+h+pad)
    crop = frame[y0:y1, x0:x1].copy()
    if iris:
        cx, cy, r = iris
        cv2.circle(crop, (cx-x0, cy-y0), r, (255,255,255), 2)
    crop = cv2.resize(crop, (480, 300), interpolation=cv2.INTER_CUBIC)
    ok, buf = cv2.imencode(".jpg", crop, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return base64.b64encode(buf).decode("ascii") if ok else None

def cosine_similarity(a, b):
    a = a.reshape(-1).astype(np.float32)
    b = b.reshape(-1).astype(np.float32)
    denom = (np.linalg.norm(a) * np.linalg.norm(b)) + 1e-8
    return float(np.dot(a, b) / denom)

def detect_iris(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)

    # Step 1: find a face. This prevents the old detector from locking onto hair/background.
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.08, minNeighbors=6, minSize=(140, 140)
    )
    if len(faces) == 0:
        return None, "No face detected. Move your face into the camera view."

    fx, fy, fw, fh = max(faces, key=lambda f: f[2] * f[3])

    # Step 2: search for eyes only in the upper ~65% of the face.
    face_gray = gray[fy:fy + int(fh * 0.68), fx:fx + fw]
    eyes = eye_cascade.detectMultiScale(
        face_gray,
        scaleFactor=1.06,
        minNeighbors=7,
        minSize=(45, 28)
    )

    if len(eyes) == 0:
        return None, "Face detected, but no clear eye was found. Look straight at the camera."

    # Prefer the largest eye candidate.
    ex, ey, ew, eh = max(eyes, key=lambda e: e[2] * e[3])
    ex += fx
    ey += fy

    eye = gray[ey:ey + eh, ex:ex + ew]
    if eye.size == 0:
        return None, "Eye region could not be processed."

    # Step 3: estimate pupil and iris with circular Hough detection.
    blur = cv2.GaussianBlur(eye, (7, 7), 1.4)
    circles = cv2.HoughCircles(
        blur,
        cv2.HOUGH_GRADIENT,
        dp=1.15,
        minDist=max(12, int(min(eye.shape) * 0.35)),
        param1=85,
        param2=18,
        minRadius=max(5, int(min(eye.shape) * 0.07)),
        maxRadius=max(9, int(min(eye.shape) * 0.32))
    )

    if circles is None:
        # Fall back to an eye-centered estimate, but mark quality lower.
        cx, cy = eye.shape[1] // 2, eye.shape[0] // 2
        pupil_r = max(4, min(eye.shape) // 9)
        fallback = True
    else:
        candidates = np.round(circles[0]).astype(int)
        # Pupil is usually the darkest/most central candidate.
        scored = []
        for c in candidates:
            cx0, cy0, r0 = c
            x0, x1 = max(0, cx0-r0), min(eye.shape[1], cx0+r0)
            y0, y1 = max(0, cy0-r0), min(eye.shape[0], cy0+r0)
            patch = eye[y0:y1, x0:x1]
            darkness = 255 - float(patch.mean()) if patch.size else 0
            central = 1 - min(
                1.0,
                np.hypot(cx0-eye.shape[1]/2, cy0-eye.shape[0]/2) /
                max(1, np.hypot(eye.shape[1]/2, eye.shape[0]/2))
            )
            scored.append((darkness * 0.7 + central * 90, cx0, cy0, r0))
        _, cx, cy, pupil_r = max(scored, key=lambda s: s[0])
        fallback = False

    cx = int(np.clip(cx, 0, eye.shape[1]-1))
    cy = int(np.clip(cy, 0, eye.shape[0]-1))
    pupil_r = int(max(4, pupil_r))

    # Estimate the iris conservatively but keep a broad visible annulus.
    # The previous version could reject good webcam frames when the estimated
    # pupil circle was slightly off-center or small.
    base = max(12, min(eye.shape) * 0.20)
    iris_r = int(np.clip(max(pupil_r * 2.25, base), min(eye.shape) * 0.18, min(eye.shape) * 0.46))

    # Keep the estimated circle inside the eye crop.
    max_r = int(min(cx, cy, eye.shape[1]-cx-1, eye.shape[0]-cy-1))
    if max_r > 8:
        iris_r = min(iris_r, int(max_r * 0.94))

    if iris_r <= pupil_r + 4:
        # Fall back to the eye-centered estimate rather than rejecting the frame.
        cx, cy = eye.shape[1] // 2, eye.shape[0] // 2
        iris_r = int(min(eye.shape) * 0.30)
        pupil_r = int(min(iris_r * 0.38, pupil_r))

    # Build a tolerant annular iris mask. Slightly enlarge the usable region
    # and only exclude the central pupil zone.
    yy, xx = np.ogrid[:eye.shape[0], :eye.shape[1]]
    dist2 = (xx-cx)**2 + (yy-cy)**2
    outer = dist2 <= iris_r**2
    inner = dist2 < int((max(3, pupil_r * 1.02))**2)
    mask = (outer & ~inner).astype(np.uint8) * 255

    # Exclude the extreme upper/lower eye margins, where eyelids commonly
    # introduce non-iris pixels, while retaining most of the iris.
    vertical = np.abs(yy - cy) <= int(iris_r * 0.92)
    mask = (mask.astype(bool) & vertical).astype(np.uint8) * 255

    valid = eye[mask > 0]
    if valid.size < 180:
        # Final fallback: use the central visible eye area.
        cx, cy = eye.shape[1] // 2, eye.shape[0] // 2
        iris_r = max(8, int(min(eye.shape) * 0.28))
        dist2 = (xx-cx)**2 + (yy-cy)**2
        mask = (dist2 <= iris_r**2).astype(np.uint8) * 255
        valid = eye[mask > 0]

    if valid.size < 120:
        return None, "Iris could not be isolated clearly. Move slightly closer and keep one eye open."

    # Quality components.
    lap = cv2.Laplacian(eye, cv2.CV_64F).var()
    focus = int(np.clip((lap - 15) / 2.8, 0, 100))

    brightness = float(valid.mean())
    illumination = int(np.clip(100 - abs(brightness - 125) * 0.85, 0, 100))

    contrast = float(valid.std())
    contrast_score = int(np.clip((contrast - 12) * 3.5, 0, 100))

    theoretical_area = max(1, np.pi * iris_r**2 * 0.82)
    visibility = int(np.clip((valid.size / theoretical_area) * 100, 0, 100))
    size_score = int(np.clip((iris_r / max(1, min(eye.shape))) * 300, 0, 100))

    quality = int(np.clip(
        focus * 0.28 +
        illumination * 0.22 +
        contrast_score * 0.18 +
        visibility * 0.17 +
        size_score * 0.15 -
        (12 if fallback else 0),
        0, 100
    ))

    descriptor = normalize_iris(eye, mask, cx, cy, pupil_r, iris_r)
    if descriptor is None:
        return None, "Iris normalization failed."

    # Coordinates are in original frame coordinates.
    return {
        "descriptor": descriptor,
        "quality": quality,
        "components": {
            "focus": focus,
            "illumination": illumination,
            "contrast": contrast_score,
            "visibility": visibility,
            "resolution": size_score
        },
        "face_box": [int(fx), int(fy), int(fw), int(fh)],
        "eye_box": [int(ex), int(ey), int(ew), int(eh)],
        "iris": [int(ex + cx), int(ey + cy), int(iris_r)],
        "eye_size": [int(ew), int(eh)],
        "eye_stats": eye_motion_signature(eye, iris_r=iris_r, eye_h=eh, visibility=visibility)
    }, None

@app.route("/")
def index():
    return render_template("index.html")


@app.post("/api/quality")
def quality():
    payload = request.get_json(silent=True) or {}
    data_url = payload.get("frame")
    if not data_url:
        return jsonify({"ok": False, "error": "No camera frame received."}), 400

    try:
        frame = decode_frame(data_url)
        result, error = detect_iris(frame)
    except Exception as exc:
        return jsonify({"ok": False, "error": f"Image processing error: {exc}"}), 400

    if result is None:
        return jsonify({"ok": True, "detected": False, "message": error})

    return jsonify({
        "ok": True,
        "detected": True,
        "quality": result["quality"],
        "components": result["components"],
        "face_box": result["face_box"],
        "eye_box": result["eye_box"],
        "iris": result["iris"],
        "eye_size": result["eye_size"],
        "eye_preview": crop_preview(frame, result["eye_box"], result["iris"])
    })


@app.post("/api/liveness")
def liveness():
    payload = request.get_json(silent=True) or {}
    frames = payload.get("frames") or []
    if len(frames) < 4:
        return jsonify({"ok": True, "state": "CALIBRATING", "score": 50,
                        "blink_events": 0, "movement": 0,
                        "message": "Collecting more live frames..."})

    results = []
    previous = None

    for data_url in frames[-10:]:
        try:
            frame = decode_frame(data_url)
            result, error = detect_iris(frame)

            if result is not None:
                previous = result
                results.append(result)
                continue

            # During a blink, Haar eye detection may temporarily fail.
            # Reuse the last successful face-relative eye location to inspect
            # the same physical eye region instead of discarding the frame.
            if previous is not None:
                pf = previous["face_box"]
                pe = previous["eye_box"]
                fx, fy, fw, fh = pf
                ex, ey, ew, eh = pe

                rx = (ex - fx) / max(1, fw)
                ry = (ey - fy) / max(1, fh)
                rw = ew / max(1, fw)
                rh = eh / max(1, fh)

                faces = face_cascade.detectMultiScale(
                    cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY),
                    scaleFactor=1.08, minNeighbors=5, minSize=(120, 120)
                )
                if len(faces):
                    fx2, fy2, fw2, fh2 = max(faces, key=lambda f: f[2] * f[3])
                    x = int(fx2 + rx * fw2)
                    y = int(fy2 + ry * fh2)
                    w = max(25, int(rw * fw2))
                    h = max(20, int(rh * fh2))
                    x = max(0, min(x, frame.shape[1]-w))
                    y = max(0, min(y, frame.shape[0]-h))
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    eye = gray[y:y+h, x:x+w]
                    if eye.size:
                        # A conservative fallback iris estimate keeps the
                        # temporal eye-state signal alive during closure.
                        eh2, ew2 = eye.shape[:2]
                        fallback_iris_r = max(4, int(min(ew2, eh2) * 0.22))
                        fallback_stats = eye_motion_signature(
                            eye, iris_r=fallback_iris_r,
                            eye_h=eh2, visibility=0
                        )
                        if fallback_stats:
                            # Mark this as a likely closure candidate by
                            # lowering iris visibility in the openness signal.
                            fallback_stats["iris_ratio"] = 0.0
                            fallback_stats["visibility"] = 0.0
                            fallback_stats["lid_signal"] = min(1.0, fallback_stats.get("lid_signal", 0.0) * 1.6)
                            results.append({"eye_stats": fallback_stats})

        except Exception:
            continue

    live = liveness_sequence(results)
    return jsonify({"ok": True, **live})

@app.get("/api/profile")
def profile_status():
    enrolled=TEMPLATE_FILE.exists(); profile={}
    if PROFILE_FILE.exists():
        try: profile=json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
        except Exception: profile={}
    return jsonify({"ok":True,"enrolled":enrolled,"profile":profile if enrolled else None})

@app.post("/api/intelligence")
def intelligence():
    payload = request.get_json(silent=True) or {}
    values = payload.get("features") or {}

    model_values = dict(values)
    if model_values.get("similarity") is None:
        # Neutral internal value for the ML feature vector. This is NOT shown
        # as an identity similarity and does not trigger a mismatch gate.
        model_values["similarity"] = 0.84

    score, level, probability = risk_model.predict(model_values)
    findings = risk_model.explain(values)

    # A compact security posture derived from ML + explicit controls.
    controls = {
        "iris_detected": bool(values.get("quality", 0) > 0),
        "liveness_pass": bool(values.get("liveness", 0) >= 70),
        "quality_pass": bool(values.get("quality", 0) >= 60),
        "stability_pass": bool(values.get("stability", 0) >= 70),
        "template_match": bool(values.get("similarity") is not None and values.get("similarity") >= 0.84)
    }

    if values.get("similarity") is None and score > 82:
        score = 82
        level = "HIGH"
    if score >= 70:
        verdict = "BLOCK / RECHECK"
    elif score >= 40:
        verdict = "STEP-UP VERIFICATION"
    else:
        verdict = "ALLOW / LOW RISK"

    result = {
        "score": score,
        "level": level,
        "probability": round(probability, 3),
        "verdict": verdict,
        "findings": findings[:5],
        "controls": controls,
        "model": "CyberDNA Gaussian ML Risk Engine v1",
        "template_available": values.get("similarity") is not None,
    }
    write_audit("risk_assessment", result)
    return jsonify({"ok": True, **result})

@app.post("/api/scan")
def scan():
    payload = request.get_json(silent=True) or {}
    frames = payload.get("frames") or []
    if not frames:
        single = payload.get("frame")
        frames = [single] if single else []
    if not frames:
        return jsonify({"ok": False, "error": "No camera frames received."}), 400

    stored = None
    if TEMPLATE_FILE.exists():
        try:
            stored = np.load(TEMPLATE_FILE)
        except Exception:
            stored = None

    candidates = []
    for data_url in frames[:12]:
        try:
            frame = decode_frame(data_url)
            result, error = detect_iris(frame)
        except Exception:
            continue
        if result is None:
            continue
        candidates.append((frame, result))

    if not candidates:
        return jsonify({"ok": True, "detected": False,
                        "message": "No stable iris was detected. Look toward the camera and hold still."})

    # Calculate liveness in chronological order before quality sorting.
    live = liveness_sequence([r for _, r in candidates[-10:]])

    # Use the best-quality frame for visualization, while verification uses
    # the best several descriptors to reduce single-frame noise.
    candidates.sort(key=lambda x: x[1]["quality"], reverse=True)
    best_frame, best = candidates[0]
    quality_values = [r["quality"] for _, r in candidates[:8]]
    descriptors = [r["descriptor"] for _, r in candidates[:8]]

    similarity = None
    matched = False
    confidence = None

    stability = max(0, 100 - float(np.std(quality_values)) * 7)
    liveness_score = int(live["score"])

    if stored is not None:
        sims = [cosine_similarity(d, stored) for d in descriptors]
        similarity = float(np.mean(sorted(sims, reverse=True)[:min(5, len(sims))]))
        # Verification remains stricter than enrollment.
        matched = similarity >= 0.84 and float(np.mean(quality_values)) >= 52 and liveness_score >= 70
        confidence = int(np.clip((similarity - 0.45) * 180, 0, 99))

    feature_values = {
        "quality": float(np.mean(quality_values)),
        "focus": float(best["components"]["focus"]),
        "illumination": float(best["components"]["illumination"]),
        "contrast": float(best["components"]["contrast"]),
        "visibility": float(best["components"]["visibility"]),
        "resolution": float(best["components"]["resolution"]),
        "liveness": liveness_score,
        "stability": stability,
        "similarity": float(similarity) if similarity is not None else 0.45,
    }
    risk_score, risk_level, risk_probability = risk_model.predict(feature_values)
    findings = risk_model.explain(feature_values)

    write_audit("verification", {"matched": matched, "quality": feature_values["quality"], "liveness": liveness_score, "stability": stability, "similarity": similarity, "risk": risk_score})

    return jsonify({
        "ok": True,
        "detected": True,
        "matched": matched,
        "quality": int(round(float(np.mean(quality_values)))),
        "best_quality": int(best["quality"]),
        "stability": int(round(stability)),
        "liveness": live,
        "components": best["components"],
        "similarity": round(similarity, 3) if similarity is not None else None,
        "confidence": confidence,
        "face_box": best["face_box"],
        "eye_box": best["eye_box"],
        "iris": best["iris"],
        "eye_size": best["eye_size"],
        "eye_preview": crop_preview(best_frame, best["eye_box"], best["iris"]),
        "profile": {
            "name": "Rohit Kumar Mohanty",
            "status": "Verified local prototype" if matched else "Awaiting verification",
            "risk": risk_score
        },
        "intelligence": {
            "score": risk_score,
            "level": risk_level,
            "probability": round(risk_probability, 3),
            "verdict": "ALLOW / LOW RISK" if risk_score < 40 else ("STEP-UP VERIFICATION" if risk_score < 70 else "BLOCK / RECHECK"),
            "findings": findings[:5],
            "liveness": liveness_score,
            "blink_events": live.get("blink_events", 0),
            "movement": live.get("movement", 0),
            "features": feature_values,
            "model": "CyberDNA Gaussian ML Risk Engine v1"
        }
    })


@app.post("/api/enroll")
def enroll():
    payload = request.get_json(silent=True) or {}
    frames = payload.get("frames") or []
    if not frames:
        single = payload.get("frame")
        frames = [single] if single else []

    descriptors = []
    qualities = []
    last = None

    for data_url in frames[:12]:
        try:
            frame = decode_frame(data_url)
            result, error = detect_iris(frame)
        except Exception:
            continue
        if result is None or result["quality"] < 45:
            continue
        descriptors.append(result["descriptor"])
        qualities.append(result["quality"])
        last = result

    if len(descriptors) < 5:
        return jsonify({
            "ok": False,
            "error": "Not enough usable iris frames. Keep one eye visible and capture for a few more seconds."
        }), 400

    live = liveness_sequence([detect_iris(decode_frame(x))[0] for x in frames[:12] if x])
    if live["score"] < 60:
        return jsonify({
            "ok": False,
            "error": "Liveness confidence is too low. Blink once naturally, then keep your eye open."
        }), 400

    template = np.mean(np.stack(descriptors), axis=0).astype(np.float32)
    np.save(TEMPLATE_FILE, template)
    profile={"name":"Rohit Kumar Mohanty","enrolled_at":datetime.now(timezone.utc).isoformat(),"frames_used":len(descriptors),"average_quality":int(round(float(np.mean(qualities)))),"template_type":"derived_local_iris_descriptor"}
    PROFILE_FILE.write_text(json.dumps(profile,indent=2),encoding="utf-8")
    write_audit("enrollment", profile)
    write_audit("enrollment", {"quality": float(np.mean(qualities)), "frames": len(descriptors), "liveness": live})

    return jsonify({
        "ok": True,
        "message": "Multi-frame iris template enrolled locally.",
        "quality": int(round(float(np.mean(qualities)))),
        "frames_used": len(descriptors),
        "liveness": live,
        "components": last["components"] if last else {}
    })


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
